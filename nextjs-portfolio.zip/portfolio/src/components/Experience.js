'use client';

import { motion } from 'framer-motion';
import SectionHeader from './SectionHeader';
import { experience } from '@/data/site';

export default function Experience() {
  return (
    <section id="experience" className="relative py-24 md:py-36 border-t border-[color:var(--line)]">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeader
          label="04 / Experience"
          kicker="The working life"
          title="Places I've been, things I've learned."
        />

        <div className="relative">
          {/* Vertical spine */}
          <div
            aria-hidden
            className="absolute left-0 md:left-[22%] top-0 bottom-0 w-px bg-[color:var(--line)]"
          />

          <ol className="space-y-12 md:space-y-16">
            {experience.map((job, i) => (
              <motion.li
                key={job.company + job.period}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.7, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
                className="relative grid grid-cols-12 gap-4 md:gap-8 pl-6 md:pl-0"
              >
                {/* Dot on spine */}
                <span
                  aria-hidden
                  className="absolute left-[-4px] md:left-[calc(22%-4px)] top-2 h-2 w-2 rounded-full bg-[color:var(--accent)]"
                />

                {/* Period */}
                <div className="col-span-12 md:col-span-3">
                  <div className="font-mono text-[11px] uppercase tracking-[0.16em] text-[color:var(--fg-muted)]">
                    {job.period}
                  </div>
                  <div className="font-mono text-[10px] uppercase tracking-[0.14em] text-[color:var(--fg-muted)] mt-1 opacity-70">
                    {job.location}
                  </div>
                </div>

                {/* Content */}
                <div className="col-span-12 md:col-span-9 md:pl-8">
                  <h3 className="font-display text-2xl md:text-3xl tracking-tightest leading-tight">
                    {job.role}
                  </h3>
                  <div className="mt-1 mb-5 text-[color:var(--accent)] font-medium">
                    {job.company}
                  </div>
                  <ul className="space-y-2.5 max-w-2xl">
                    {job.bullets.map((b, bi) => (
                      <li
                        key={bi}
                        className="flex gap-3 text-[color:var(--fg-soft)] leading-relaxed"
                      >
                        <span
                          aria-hidden
                          className="flex-shrink-0 mt-2.5 inline-block h-px w-3 bg-[color:var(--fg-muted)]"
                        />
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.li>
            ))}
          </ol>
        </div>

        <div className="mt-16 md:mt-20 text-center">
          <a
            href="/resume.pdf"
            className="inline-flex items-center gap-2 text-sm font-mono uppercase tracking-[0.16em] text-[color:var(--fg-muted)] hover:text-[color:var(--accent)] transition-colors link-hover"
          >
            Download full resume →
          </a>
        </div>
      </div>
    </section>
  );
}
