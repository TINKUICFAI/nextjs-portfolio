'use client';

import { motion } from 'framer-motion';
import { ArrowDownRight } from 'lucide-react';
import { site } from '@/data/site';

export default function Hero() {
  return (
    <section id="top" className="relative min-h-[100svh] flex items-center grain overflow-hidden">
      {/* Decorative column guides */}
      <div
        aria-hidden
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage:
            'linear-gradient(to right, transparent 0, transparent calc(50% - 0.5px), var(--line) calc(50% - 0.5px), var(--line) calc(50% + 0.5px), transparent calc(50% + 0.5px))',
          opacity: 0.35,
        }}
      />

      <div className="relative mx-auto max-w-7xl px-6 lg:px-10 pt-32 pb-20 w-full">
        {/* Availability pill */}
        {site.available && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[color:var(--line)] text-xs font-mono uppercase tracking-[0.15em]"
          >
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-75 animate-ping" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-green-500" />
            </span>
            Available for work
          </motion.div>
        )}

        {/* Display headline */}
        <div className="mt-8 grid grid-cols-12 gap-4">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="col-span-12 font-display text-[clamp(3rem,10vw,9rem)] leading-[0.95] tracking-tightest text-balance"
          >
            <span className="block">{site.name}</span>
            <span className="block italic text-[color:var(--accent)]">builds</span>
            <span className="block">things.</span>
          </motion.h1>
        </div>

        {/* Tagline & CTA */}
        <div className="mt-12 grid grid-cols-12 gap-6 items-end">
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.55 }}
            className="col-span-12 md:col-span-7 text-lg md:text-xl text-[color:var(--fg-soft)] leading-relaxed text-balance max-w-xl"
          >
            {site.tagline}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.7 }}
            className="col-span-12 md:col-span-5 md:justify-self-end flex flex-col sm:flex-row items-start sm:items-center gap-4"
          >
            <a
              href="#work"
              className="group inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[color:var(--fg)] text-[color:var(--bg)] hover:bg-[color:var(--accent)] transition-colors"
            >
              <span className="text-sm font-medium">See the work</span>
              <ArrowDownRight
                size={16}
                strokeWidth={1.8}
                className="transition-transform group-hover:translate-x-0.5 group-hover:translate-y-0.5"
              />
            </a>
            <a
              href="#contact"
              className="text-sm text-[color:var(--fg-soft)] link-hover"
            >
              Or get in touch →
            </a>
          </motion.div>
        </div>

        {/* Footer meta */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.1 }}
          className="mt-20 pt-6 rule grid grid-cols-2 md:grid-cols-4 gap-6 text-xs font-mono uppercase tracking-[0.14em] text-[color:var(--fg-muted)]"
        >
          <div>
            <div className="text-[10px] opacity-60 mb-1">Location</div>
            <div className="text-[color:var(--fg-soft)]">{site.location}</div>
          </div>
          <div>
            <div className="text-[10px] opacity-60 mb-1">Role</div>
            <div className="text-[color:var(--fg-soft)]">{site.role}</div>
          </div>
          <div>
            <div className="text-[10px] opacity-60 mb-1">Status</div>
            <div className="text-[color:var(--fg-soft)]">Accepting projects</div>
          </div>
          <div>
            <div className="text-[10px] opacity-60 mb-1">Year</div>
            <div className="text-[color:var(--fg-soft)]">MMXXVI</div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
