export default function SectionHeader({ label, title, kicker }) {
  return (
    <div className="mb-14 md:mb-20 grid grid-cols-12 gap-4 items-end">
      <div className="col-span-12 md:col-span-2">
        <div className="font-mono text-[11px] uppercase tracking-[0.2em] text-[color:var(--fg-muted)]">
          {label}
        </div>
      </div>
      <div className="col-span-12 md:col-span-10">
        {kicker && (
          <div className="font-mono text-xs text-[color:var(--accent)] mb-3 uppercase tracking-[0.15em]">
            {kicker}
          </div>
        )}
        <h2 className="font-display text-4xl md:text-6xl tracking-tightest leading-[1.05] text-balance max-w-3xl">
          {title}
        </h2>
      </div>
    </div>
  );
}
