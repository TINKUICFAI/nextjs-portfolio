'use client';

import { motion } from 'framer-motion';
import SectionHeader from './SectionHeader';
import { about } from '@/data/site';

export default function About() {
  return (
    <section id="about" className="relative py-24 md:py-36 border-t border-[color:var(--line)]">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeader label="02 / About" kicker="A short bio" title={about.headline} />

        <div className="grid grid-cols-12 gap-6 lg:gap-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.8 }}
            className="col-span-12 md:col-span-8 space-y-6"
          >
            {about.paragraphs.map((p, i) => (
              <p
                key={i}
                className={`leading-relaxed text-[color:var(--fg-soft)] ${
                  i === 0 ? 'text-xl md:text-2xl text-[color:var(--fg)] font-display tracking-tightest' : 'text-base md:text-lg'
                }`}
              >
                {p}
              </p>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.8, delay: 0.15 }}
            className="col-span-12 md:col-span-4 md:border-l md:border-[color:var(--line)] md:pl-8"
          >
            <dl className="space-y-5">
              {about.facts.map((fact) => (
                <div key={fact.label}>
                  <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-[color:var(--fg-muted)] mb-1">
                    {fact.label}
                  </dt>
                  <dd className="text-[color:var(--fg)]">{fact.value}</dd>
                </div>
              ))}
            </dl>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
