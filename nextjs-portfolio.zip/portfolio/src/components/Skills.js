'use client';

import { motion } from 'framer-motion';
import SectionHeader from './SectionHeader';
import { skills } from '@/data/site';

export default function Skills() {
  // Flatten all skills for the marquee
  const allSkills = skills.flatMap((g) => g.items);

  return (
    <section id="skills" className="relative py-24 md:py-36 border-t border-[color:var(--line)] overflow-hidden">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeader
          label="03 / Skills"
          kicker="Tools of the trade"
          title="What I reach for when solving a problem."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-[color:var(--line)] border border-[color:var(--line)]">
          {skills.map((group, gi) => (
            <motion.div
              key={group.group}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, delay: gi * 0.1 }}
              className="bg-[color:var(--bg)] p-6 md:p-8"
            >
              <div className="flex items-baseline gap-2 mb-6">
                <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-[color:var(--fg-muted)]">
                  {String(gi + 1).padStart(2, '0')}
                </span>
                <h3 className="font-display text-xl tracking-tightest">{group.group}</h3>
              </div>
              <ul className="space-y-2.5">
                {group.items.map((item) => (
                  <li
                    key={item}
                    className="flex items-center gap-3 text-[color:var(--fg-soft)] text-sm"
                  >
                    <span
                      className="inline-block h-px w-3 bg-[color:var(--fg-muted)]"
                      aria-hidden
                    />
                    {item}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Marquee strip */}
      <div className="mt-20 py-8 border-y border-[color:var(--line)] mask-fade-x">
        <div className="flex gap-12 animate-marquee whitespace-nowrap w-max">
          {[...allSkills, ...allSkills].map((s, i) => (
            <span
              key={i}
              className="font-display italic text-4xl md:text-6xl tracking-tightest text-[color:var(--fg-muted)]"
            >
              {s} <span className="text-[color:var(--accent)] not-italic">✦</span>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
