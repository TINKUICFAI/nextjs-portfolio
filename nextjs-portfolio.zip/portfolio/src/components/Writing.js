'use client';

import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';
import SectionHeader from './SectionHeader';
import { writing } from '@/data/site';

function formatDate(iso) {
  return new Date(iso).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export default function Writing() {
  return (
    <section id="writing" className="relative py-24 md:py-36 border-t border-[color:var(--line)]">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeader
          label="05 / Writing"
          kicker="Essays & field notes"
          title="Occasional writing on craft, design, and the work."
        />

        <ol className="divide-y divide-[color:var(--line)] border-y border-[color:var(--line)]">
          {writing.map((post, i) => (
            <motion.li
              key={post.title}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, delay: i * 0.08 }}
            >
              <a
                href={post.href}
                className="group grid grid-cols-12 gap-4 py-6 md:py-8 items-baseline hover:bg-[color:var(--line)]/20 -mx-4 px-4 transition-colors"
              >
                <div className="col-span-12 md:col-span-2 font-mono text-[11px] uppercase tracking-[0.16em] text-[color:var(--fg-muted)]">
                  {formatDate(post.date)}
                </div>
                <div className="col-span-12 md:col-span-8">
                  <h3 className="font-display text-2xl md:text-3xl tracking-tightest leading-tight text-balance group-hover:text-[color:var(--accent)] transition-colors">
                    {post.title}
                  </h3>
                  <p className="mt-3 text-[color:var(--fg-soft)] leading-relaxed max-w-2xl">
                    {post.excerpt}
                  </p>
                </div>
                <div className="col-span-12 md:col-span-2 flex md:justify-end items-center gap-2 text-[color:var(--fg-muted)]">
                  <span className="font-mono text-[11px] uppercase tracking-[0.14em]">
                    {post.readTime}
                  </span>
                  <ArrowUpRight
                    size={16}
                    strokeWidth={1.4}
                    className="group-hover:text-[color:var(--accent)] group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition-all"
                  />
                </div>
              </a>
            </motion.li>
          ))}
        </ol>

        <div className="mt-12 text-center">
          <a
            href="/writing"
            className="inline-flex items-center gap-2 text-sm font-mono uppercase tracking-[0.16em] text-[color:var(--fg-muted)] hover:text-[color:var(--accent)] transition-colors link-hover"
          >
            Read all essays →
          </a>
        </div>
      </div>
    </section>
  );
}
