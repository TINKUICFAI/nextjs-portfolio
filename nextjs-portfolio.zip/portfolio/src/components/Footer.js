import { site } from '@/data/site';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-[color:var(--line)]">
      <div className="mx-auto max-w-7xl px-6 lg:px-10 py-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-baseline gap-3">
          <span className="font-display text-lg italic tracking-tightest">{site.name}.</span>
          <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-[color:var(--fg-muted)]">
            © {year} — All rights reserved
          </span>
        </div>

        <div className="flex items-center gap-6 font-mono text-[10px] uppercase tracking-[0.18em] text-[color:var(--fg-muted)]">
          <span>Set in Fraunces & Inter</span>
          <span className="hidden md:inline">•</span>
          <span className="hidden md:inline">Built with Next.js</span>
          <span className="hidden md:inline">•</span>
          <a href="#top" className="hover:text-[color:var(--accent)] transition-colors">
            Back to top ↑
          </a>
        </div>
      </div>
    </footer>
  );
}
