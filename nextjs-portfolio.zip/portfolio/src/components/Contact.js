'use client';

import { motion } from 'framer-motion';
import { ArrowUpRight, Copy, Check } from 'lucide-react';
import { useState } from 'react';
import { site, socials } from '@/data/site';

export default function Contact() {
  const [copied, setCopied] = useState(false);

  const onCopy = async () => {
    try {
      await navigator.clipboard.writeText(site.email);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {}
  };

  return (
    <section id="contact" className="relative py-24 md:py-40 border-t border-[color:var(--line)] grain">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="font-mono text-[11px] uppercase tracking-[0.2em] text-[color:var(--fg-muted)] mb-6">
          06 / Contact
        </div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
          className="font-display text-[clamp(3rem,9vw,8rem)] leading-[0.95] tracking-tightest text-balance max-w-5xl"
        >
          Let's make
          <br />
          <span className="italic text-[color:var(--accent)]">something</span> good.
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7, delay: 0.25 }}
          className="mt-8 max-w-xl text-lg text-[color:var(--fg-soft)] leading-relaxed"
        >
          I'm currently open to new projects and collaborations. The best way to reach me
          is email — I read everything, reply within a day or two.
        </motion.p>

        {/* Email block */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="mt-12 flex flex-wrap items-center gap-4"
        >
          <a
            href={`mailto:${site.email}`}
            className="group inline-flex items-center gap-3 px-7 py-4 rounded-full bg-[color:var(--fg)] text-[color:var(--bg)] hover:bg-[color:var(--accent)] transition-colors"
          >
            <span className="text-base font-medium">{site.email}</span>
            <ArrowUpRight
              size={18}
              strokeWidth={1.6}
              className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
            />
          </a>
          <button
            onClick={onCopy}
            aria-label="Copy email address"
            className="inline-flex items-center gap-2 px-5 py-4 rounded-full border border-[color:var(--line)] hover:border-[color:var(--fg)] transition-colors text-sm"
          >
            {copied ? (
              <>
                <Check size={14} strokeWidth={1.8} />
                Copied
              </>
            ) : (
              <>
                <Copy size={14} strokeWidth={1.8} />
                Copy
              </>
            )}
          </button>
        </motion.div>

        {/* Socials grid */}
        <div className="mt-20 pt-10 border-t border-[color:var(--line)] grid grid-cols-2 md:grid-cols-4 gap-8">
          {socials.map((s, i) => (
            <motion.a
              key={s.label}
              href={s.href}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, delay: i * 0.06 }}
              className="group block"
            >
              <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-[color:var(--fg-muted)] mb-2">
                {s.label}
              </div>
              <div className="flex items-center gap-1.5 text-[color:var(--fg-soft)] group-hover:text-[color:var(--accent)] transition-colors">
                <span className="link-hover">{s.handle}</span>
                <ArrowUpRight
                  size={12}
                  strokeWidth={1.6}
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                />
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
