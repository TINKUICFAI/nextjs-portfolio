'use client';

import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';
import SectionHeader from './SectionHeader';
import { projects } from '@/data/site';

export default function Work() {
  return (
    <section id="work" className="relative py-24 md:py-36 border-t border-[color:var(--line)]">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeader
          label="01 / Work"
          kicker="Selected projects"
          title="Things I've shipped, shaped, and occasionally rebuilt."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-10">
          {projects.map((p, i) => (
            <motion.a
              key={p.title}
              href={p.href}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ duration: 0.7, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
              className="group relative block p-6 md:p-8 border border-[color:var(--line)] hover:border-[color:var(--fg)] transition-colors"
              style={{ background: 'var(--bg)' }}
            >
              {/* Accent swatch */}
              <div
                className="absolute top-0 left-0 h-1 w-full transition-transform origin-left scale-x-0 group-hover:scale-x-100 duration-500"
                style={{ background: p.accent }}
              />

              <div className="flex items-start justify-between gap-4 mb-8">
                <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-[color:var(--fg-muted)]">
                  {p.year} — {p.role}
                </div>
                <ArrowUpRight
                  size={18}
                  strokeWidth={1.4}
                  className="text-[color:var(--fg-muted)] group-hover:text-[color:var(--accent)] group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition-all"
                />
              </div>

              <h3 className="font-display text-3xl md:text-4xl tracking-tightest leading-[1.05] mb-4">
                {p.title}
              </h3>

              <p className="text-[color:var(--fg-soft)] leading-relaxed mb-8 max-w-md">
                {p.summary}
              </p>

              <div className="flex flex-wrap gap-1.5">
                {p.stack.map((s) => (
                  <span
                    key={s}
                    className="font-mono text-[10px] uppercase tracking-[0.12em] px-2 py-1 border border-[color:var(--line)] text-[color:var(--fg-muted)]"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
