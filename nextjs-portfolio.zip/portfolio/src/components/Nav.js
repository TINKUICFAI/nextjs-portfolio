'use client';

import { useState, useEffect } from 'react';
import { useTheme } from 'next-themes';
import { Moon, Sun, Menu, X } from 'lucide-react';
import { nav, site } from '@/data/site';

export default function Nav() {
  const [mounted, setMounted] = useState(false);
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { theme, setTheme } = useTheme();

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <>
      <header
        className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'backdrop-blur-md bg-[color:var(--bg)]/75 border-b border-[color:var(--line)]'
            : 'bg-transparent border-b border-transparent'
        }`}
      >
        <div className="mx-auto max-w-7xl px-6 lg:px-10 h-16 flex items-center justify-between">
          <a href="#top" className="group flex items-center gap-3">
            <span className="font-display text-xl tracking-tightest italic">{site.name}.</span>
            <span className="hidden sm:inline-block font-mono text-[11px] uppercase tracking-[0.18em] text-[color:var(--fg-muted)]">
              {site.role}
            </span>
          </a>

          <nav className="hidden md:flex items-center gap-1">
            {nav.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="px-3 py-2 text-sm text-[color:var(--fg-soft)] hover:text-[color:var(--fg)] transition-colors"
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              aria-label="Toggle theme"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-2 rounded-full border border-[color:var(--line)] hover:border-[color:var(--fg)] transition-colors"
            >
              {mounted && theme === 'dark' ? (
                <Sun size={16} strokeWidth={1.5} />
              ) : (
                <Moon size={16} strokeWidth={1.5} />
              )}
            </button>
            <button
              aria-label="Open menu"
              onClick={() => setOpen(true)}
              className="md:hidden p-2 rounded-full border border-[color:var(--line)]"
            >
              <Menu size={16} strokeWidth={1.5} />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile sheet */}
      {open && (
        <div className="fixed inset-0 z-[60] md:hidden">
          <div
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />
          <div className="absolute top-0 right-0 bottom-0 w-72 bg-[color:var(--bg)] border-l border-[color:var(--line)] p-8 flex flex-col">
            <div className="flex justify-end">
              <button aria-label="Close menu" onClick={() => setOpen(false)} className="p-2">
                <X size={18} strokeWidth={1.5} />
              </button>
            </div>
            <nav className="mt-8 flex flex-col gap-1">
              {nav.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className="font-display text-3xl tracking-tightest py-2 hover:text-[color:var(--accent)] transition-colors"
                >
                  {item.label}
                </a>
              ))}
            </nav>
          </div>
        </div>
      )}
    </>
  );
}
