// All portfolio content lives here. Edit this one file to update the site.
// Once you share your resume, just replace the placeholder values below.

export const site = {
  name: 'Tinku',
  role: 'Developer & Designer',
  location: 'Dehradun, India',
  email: 'hello@example.com',
  url: 'https://portfolio-tinkuicfai.vercel.app',
  description:
    'Portfolio of Tinku — building thoughtful digital products at the intersection of design and engineering.',
  keywords: ['portfolio', 'developer', 'designer', 'next.js', 'react'],
  tagline:
    'I build quiet, considered software — interfaces that feel inevitable, systems that respect the people who use them.',
  available: true, // shows "Available for work" pill in hero
};

export const socials = [
  { label: 'GitHub', href: 'https://github.com/TINKUICFAI', handle: '@TINKUICFAI' },
  { label: 'LinkedIn', href: 'https://linkedin.com/in/', handle: 'in/tinku' },
  { label: 'Twitter', href: 'https://twitter.com/', handle: '@tinku' },
  { label: 'Email', href: 'mailto:hello@example.com', handle: 'hello@example.com' },
];

export const nav = [
  { label: 'Work', href: '#work' },
  { label: 'About', href: '#about' },
  { label: 'Skills', href: '#skills' },
  { label: 'Experience', href: '#experience' },
  { label: 'Writing', href: '#writing' },
  { label: 'Contact', href: '#contact' },
];

export const projects = [
  {
    title: 'Lumen Analytics',
    year: '2025',
    role: 'Full-stack · Design',
    summary:
      'Real-time analytics platform for creators. Built a zero-config event pipeline and a dashboard that loads in under 400ms on 3G.',
    stack: ['Next.js', 'PostgreSQL', 'ClickHouse', 'TypeScript'],
    href: '#',
    accent: '#C45A3D',
  },
  {
    title: 'Folio CMS',
    year: '2024',
    role: 'Engineering Lead',
    summary:
      'Headless CMS built around a block-based editor. Shipped to 3 enterprise customers with 99.98% uptime in the first year.',
    stack: ['TypeScript', 'tRPC', 'Prisma', 'Redis'],
    href: '#',
    accent: '#6A8E6A',
  },
  {
    title: 'Atlas Design System',
    year: '2024',
    role: 'Design Engineer',
    summary:
      'Multi-brand design system serving 40+ engineers across 6 product teams. Dropped design-to-ship time by half.',
    stack: ['React', 'Radix', 'Tailwind', 'Storybook'],
    href: '#',
    accent: '#3D6EC4',
  },
  {
    title: 'Quiet Reader',
    year: '2023',
    role: 'Solo Project',
    summary:
      'A reading app that strips the web back to text. 12k monthly active readers, featured on Product Hunt.',
    stack: ['Next.js', 'Readability', 'Postgres'],
    href: '#',
    accent: '#A968C1',
  },
];

export const about = {
  headline: 'A quick introduction.',
  paragraphs: [
    "I'm a developer and designer based in Dehradun. I've spent the last several years building products at the seam where engineering meets craft — design systems, editor tools, and the occasional weekend experiment.",
    'My work tends toward the quiet end of the spectrum. I care about typography, timing, the way an interface feels at 2am when someone is tired. I believe good software disappears into use.',
    "Outside of work I hike in the Garhwal hills, collect old cameras I don't know how to operate, and argue with myself about serifs.",
  ],
  facts: [
    { label: 'Based in', value: 'Dehradun, IN' },
    { label: 'Years building', value: '6+' },
    { label: 'Currently', value: 'Open to new work' },
    { label: 'Timezone', value: 'IST (UTC+5:30)' },
  ],
};

export const skills = [
  {
    group: 'Languages',
    items: ['TypeScript', 'JavaScript', 'Python', 'Go', 'SQL'],
  },
  {
    group: 'Frameworks',
    items: ['Next.js', 'React', 'Node.js', 'FastAPI', 'tRPC'],
  },
  {
    group: 'Infrastructure',
    items: ['PostgreSQL', 'Redis', 'Docker', 'AWS', 'Vercel'],
  },
  {
    group: 'Craft',
    items: ['Design systems', 'Type setting', 'Motion', 'Accessibility', 'Performance'],
  },
];

export const experience = [
  {
    company: 'Northstar Labs',
    role: 'Senior Product Engineer',
    period: '2023 — Present',
    location: 'Remote',
    bullets: [
      'Led the migration from a legacy monolith to a modular Next.js platform serving 1.2M monthly users.',
      'Shipped the company design system, now used across 4 product surfaces.',
      'Mentored 3 junior engineers through structured pairing and weekly reviews.',
    ],
  },
  {
    company: 'Blueprint Studio',
    role: 'Design Engineer',
    period: '2021 — 2023',
    location: 'Bangalore, IN',
    bullets: [
      'Designed and built editor tools for a B2B SaaS customer with 50k seats.',
      'Reduced first-contentful-paint from 2.4s to 0.9s via asset budgeting and route-level splitting.',
    ],
  },
  {
    company: 'Freelance',
    role: 'Full-stack Developer',
    period: '2019 — 2021',
    location: 'Dehradun, IN',
    bullets: [
      'Delivered 18 client projects across e-commerce, publishing, and SaaS.',
      'Built long-term relationships with 4 retainer clients.',
    ],
  },
];

export const writing = [
  {
    title: 'Against the cult of the hero component',
    date: '2025-02-14',
    readTime: '6 min',
    excerpt:
      'Why I stopped starting designs from a hero and started from the humblest component on the page.',
    href: '#',
  },
  {
    title: 'Notes on building a small, honest design system',
    date: '2024-11-03',
    readTime: '12 min',
    excerpt:
      'Lessons from a year of shipping Atlas — what worked, what I would burn down and rebuild.',
    href: '#',
  },
  {
    title: 'The case for serifs on the web in 2024',
    date: '2024-06-21',
    readTime: '4 min',
    excerpt:
      'Variable serif fonts have quietly become one of the most undervalued tools in the modern designer’s kit.',
    href: '#',
  },
];
