import Link from 'next/link';

export default function NotFound() {
  return (
    <main className="min-h-screen flex items-center justify-center px-6 grain">
      <div className="text-center">
        <div className="font-mono text-[11px] uppercase tracking-[0.2em] text-[color:var(--fg-muted)] mb-4">
          Error 404
        </div>
        <h1 className="font-display text-7xl md:text-9xl tracking-tightest leading-none">
          Lost in the <span className="italic text-[color:var(--accent)]">margins</span>.
        </h1>
        <p className="mt-8 text-[color:var(--fg-soft)] max-w-md mx-auto">
          This page doesn't exist, or it moved, or it never did. Either way — back to
          solid ground.
        </p>
        <Link
          href="/"
          className="mt-10 inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[color:var(--fg)] text-[color:var(--bg)] hover:bg-[color:var(--accent)] transition-colors text-sm"
        >
          Return home →
        </Link>
      </div>
    </main>
  );
}
