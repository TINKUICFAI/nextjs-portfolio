# Portfolio — Tinku

Personal portfolio built with Next.js 14 (App Router), Tailwind CSS, and Framer Motion.

Live: <https://portfolio-tinkuicfai.vercel.app>

## Editing content

**All copy lives in one file:** `src/data/site.js`

Open it and replace placeholder values for:

- `site` — your name, role, tagline, email, availability
- `socials` — social links
- `nav` — navigation items
- `projects` — work/projects list
- `about` — bio + quick facts sidebar
- `skills` — grouped skill categories
- `experience` — resume/work history
- `writing` — blog posts

No component edits needed for normal updates.

## Running locally

```bash
npm install
npm run dev
```

Open <http://localhost:3000>.

## Design tokens

Colors, spacing, and fonts are defined in two places:

- `src/app/globals.css` — CSS custom properties (`--bg`, `--fg`, `--accent`, etc.) for light + dark mode
- `tailwind.config.js` — Tailwind theme extension

Current palette:

| Token | Light | Dark |
|---|---|---|
| bg | `#F5F1EA` (paper) | `#0E0E0C` (ink) |
| fg | `#151413` | `#EDE7DC` |
| accent | `#C45A3D` (terracotta) | `#E4927A` (soft coral) |

Typography: **Fraunces** (display) + **Inter** (body) + **JetBrains Mono** (labels).

## Deployment (Vercel)

The repo is already connected to Vercel. Push to `main` and it auto-deploys:

```bash
git add .
git commit -m "Update portfolio content"
git push origin main
```

To deploy a fresh copy elsewhere:

1. Push this code to a GitHub repo
2. Go to <https://vercel.com/new>, import the repo
3. Framework preset: **Next.js** (auto-detected)
4. No environment variables needed
5. Click Deploy

## Structure

```
src/
├── app/
│   ├── globals.css      # design tokens, grain texture, scrollbar
│   ├── layout.js        # fonts, metadata, theme provider
│   ├── page.js          # home page composition
│   └── not-found.js     # 404 page
├── components/
│   ├── Nav.js           # sticky nav + mobile sheet + theme toggle
│   ├── Hero.js          # landing section
│   ├── Work.js          # projects grid
│   ├── About.js         # bio + facts
│   ├── Skills.js        # grouped skills + marquee
│   ├── Experience.js    # timeline
│   ├── Writing.js       # blog list
│   ├── Contact.js       # CTA + socials
│   ├── Footer.js
│   ├── SectionHeader.js
│   └── ThemeProvider.js
└── data/
    └── site.js          # 🎯 ALL CONTENT — edit this file
```
